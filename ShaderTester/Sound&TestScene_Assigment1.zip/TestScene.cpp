#include "TestScene.h"


TestScene::TestScene(void)
{
}


TestScene::~TestScene(void)
{
}

bool TestScene::init(){
    Scene::init();

    /* Set custom scene Shader */

    /* Camera Settings */
    topCam->mBackward(0.5);
    rightCam->mBackward(0.5);
    frontCam->SetPosition(Vector3f(0,0,0));

    perspCam->SetPosition(Vector3f(50, 50, -50));
    perspCam->SetFocus(Vector3f(0, 0, 0));
    perspCam->wireFrame = false;

    /* Sound Assignment */
    sound1_Assignment_RotateClock = new myTimer("Rotation Clock");
    sound1_Assignment_RotateClock->start();
    sound1_Assignment_RotateClock->pause();
    sound1_Assignment_TransClock = new myTimer("Translate Clock");
    sound1_Assignment_TransClock->start();
    sound1_Assignment_TransClock->pause();
    
    /* Entities */
    Entity * temp;

    temp = new Entity("Resources/Models/morphTest1_model.obj", sceneShader);
    temp->addModel("Resources/Models/morphTest2_model.obj");
    temp->addModel("Resources/Models/morphTest3_model.obj");
    temp->texture = TextureUtils::loadSphereEnvMap("Resources/Images/sky.jpg");
  //temp->texture = TextureUtils::loadCubeEnvMap("Resources/Images/mars");
  //temp->texture = TextureUtils::loadTexture("Resources/Images/missing.png");
    temp->setStartPosition(0,0,0);
    temp->setPosition(0,0,0);
    temp->textureType = DIF_MAP;
    temp->scene = this;
    listOfEntities.push_back(temp);

    temp = new Entity("Resources/Models/AlienShip_model.obj", sceneShader);
  //temp->texture = TextureUtils::loadCubeEnvMap("Resources/Images/images/mars");
  //temp->texture = TextureUtils::loadSphereEnvMap("Resources/Images/sky.jpg");
    temp->texture = TextureUtils::loadTexture("Resources/Images/missing.png");
    temp->textureType = SPHERE_MAP;
    temp->setScale(0.3);
    temp->setPosition(100,0,0);
    temp->setStartPosition(100,0,0);
    temp->scene = this;
    listOfEntities.push_back(temp);

    /* Set Player */
    currPlayer = temp;

    rDown = false;

    
    /* Sound */
    std::string soundName;
    std::cout<<"\n\n******************************************************************************";
    std::cout<<"\nPlace a sound in the '../Resources/Sounds' folder,and type the name here: \n";
    std::cin >> soundName;

    sceneSound = sounds->addSound("Resources/Sounds/"+soundName);

    return 1;
}
void TestScene::update(float delta){
    Scene::update(delta);
    sound1_Assignment_RotateClock->update(delta);
    sound1_Assignment_TransClock->update(delta);

    //Keys
    {
        if(input->keys->isKeyPressed(sf::Keyboard::R)){
            rDown = true;
        }
        if(!input->keys->isKeyPressed(sf::Keyboard::R)){
            if(rDown == true){
                sceneSound->toggleMode();
                rDown = false;
            }
        }
        /* I should attach sounds to entities... */
        if(input->keys->isKeyPressed(sf::Keyboard::D)){
            sound1_Assignment_TransClock->unpause();
            currPlayer->setPosition(currPlayer->getStartPosition()*(sin(1-sound1_Assignment_TransClock->getCurrentTime())) );
        }
        if(!input->keys->isKeyPressed(sf::Keyboard::D)){
            sound1_Assignment_TransClock->pause();
        }
        if(input->keys->isKeyPressed(sf::Keyboard::Z)){
            sound1_Assignment_RotateClock->reset();
            sound1_Assignment_RotateClock->start();
            sound1_Assignment_TransClock->reset();
            sound1_Assignment_TransClock->start();
            currPlayer->setPosition(currPlayer->getStartPosition());
        }
        if(input->keys->isKeyPressed(sf::Keyboard::P)){
            sound1_Assignment_RotateClock->unpause();
        }
        if(!input->keys->isKeyPressed(sf::Keyboard::P)){
            sound1_Assignment_RotateClock->pause();
        }
    }

    currPlayer->setPosition( 
            currPlayer->getPosition().length() * sin(sound1_Assignment_RotateClock->getCurrentTime()),
            0,
            currPlayer->getPosition().length() * cos(sound1_Assignment_RotateClock->getCurrentTime()) );
    sceneSound->setPosition(
        currPlayer->getPosition().x,
        currPlayer->getPosition().y,
        currPlayer->getPosition().z);
}

void TestScene::draw(){
    Scene::draw();
}