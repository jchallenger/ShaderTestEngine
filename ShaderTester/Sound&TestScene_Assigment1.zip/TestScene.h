#pragma once
#include "Scene.h"
class TestScene: public Scene
{
public:
    TestScene(void);
    ~TestScene(void);
    
    bool init();
    void update(float delta);
    void draw();

    bool rDown;
    myTimer * sound1_Assignment_RotateClock, * sound1_Assignment_TransClock;
};

